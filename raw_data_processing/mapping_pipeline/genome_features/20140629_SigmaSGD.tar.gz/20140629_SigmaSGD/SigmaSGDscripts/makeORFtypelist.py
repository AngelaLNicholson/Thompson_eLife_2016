#140629 MKT
#make a list of ORFs with ORF classification = 'Dubious', 'Uncharacterized', 'Characterized' or none (i.e. no given ORF classification for transposons, etc.)

import sys
import argparse

def parseGff(annfile, orf_class):
    '''Parse the gff provided by Matt Edwards. I think that gff should also be 1-based and inclusive'''
    
    ORFs= set()
    
    f= open(annfile, 'r')
    for line in f:
        if line.startswith('#'):
            continue
        elif line.startswith('###'):
            break
        fields= line.strip('\n').split('\t')
        chrom= fields[0]
        region= fields[2]
        start= int(fields[3])
        end= int(fields[4])
        strand= fields[6]
        subattributes= fields[8].split(';')
        keys= [i.split('=')[0] for i in subattributes]
        vals=[]
        for i in subattributes:
            try:
                vals.append(i.split('=')[1])
            except:
                vals.append('')
        attd= dict(zip(keys, vals))
        
        if region=='CDS':
            ID= attd['Parent'].split('_')[0] #get rid of the _mRNA part
        
            if 'orf_classification' not in attd:
                if orf_class=='None':
                    ORFs.add(ID)
                continue
            else:
                if attd['orf_classification']== orf_class:
                    ORFs.add(ID)
                    
    return ORFs


def writeOut(orfs, outFile):
    
    f= open(outFile, 'w')
    for o in orfs:
        f.write('%s\n' % o)
    f.close()

def main(argList):
    
    parser= argparse.ArgumentParser(description='parse command line args')
    parser.add_argument('gffFile', help='input a .gff file that has fields with orf_classification field')
    parser.add_argument('outFile', help='out file will be a tab-delimited file with ORF names')
    parser.add_argument('-orf_class', help='add the classification type, i.e. Verified, Uncharacterized, Dubious, None')
    
    ar= parser.parse_args(args=argList)
    args= vars(ar)
    
    orfs= parseGff(args['gffFile'], args['orf_class'])
    writeOut(orfs, args['outFile'])
    
main(sys.argv[1:])