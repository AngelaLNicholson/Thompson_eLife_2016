#140629 MKT
#given a tab-delimited file of systematic gene names, add or remove them as needed from the .tab and cds.p annotation files

import sys
import argparse
import cPickle as pickle

def unpickle(infile):
    f= open(infile, 'r')
    d= pickle.load(f)
    f.close()
    return d

def parseGenes(geneFile):
    genes=set()
    f= open(geneFile, 'r')
    for line in f:
        gene= line.strip('\n')
        if gene!= '':
            genes.add(gene)
    f.close()
    return genes

def RemoveTab(tabFile, outfile, genes):
    
    outname= '%s.tab' % outfile
    
    f= open(tabFile, 'r')
    g= open(outname, 'w')
    
    for line in f:
        fields= line.strip('\n').split('\t')
        gene= fields[0]
        if gene not in genes:
            g.write(line)
    f.close()
    g.close()

def AddTab(tabFile, outfile, genes):
    
    outname= '%s.tab' % outfile
    
    f= open(tabFile, 'r')
    g= open(outname, 'w')
    
    for line in f:
        fields= line.strip('\n').split('\t')
        gene= fields[0]
        if gene in genes:
            g.write(line)
    f.close()
    g.close()
    
def RemoveCDS(d, outfile, genes):
    
    removed=0
    
    newd={}
    for gene in d:
        if gene not in genes:
            newd[gene]= d[gene]
        else:
            removed+=1
    f= open('%s.p' % outfile, 'w')
    pickle.dump(newd, f)
    f.close()
    print 'removed', removed
    
def AddCDS(d, outfile, genes):
    
    newd={}
    for gene in d:
        if gene in genes:
            newd[gene]= d[gene]
    f= open('%s.p' % outfile, 'w')
    pickle.dump(newd, f)
    f.close()

def main(argList):
    
    parser= argparse.ArgumentParser(description='parse command line args')
    parser.add_argument('tabFile', help='input a .gff file that has fields with orf_classification field')
    parser.add_argument('pickledCDSFile', help='out file will be a tab-delimited file with ORF names')
    parser.add_argument('outprefix', help= 'prefix for the output files')
    parser.add_argument('-geneset', help='a tab-delimited file containing genes to be added or removed')
    parser.add_argument('-keep', action='store_true', help='keep only the genes in the geneset')
    parser.add_argument('-remove', action='store_true', help= 'get rid of the genes in the file')
    
    ar= parser.parse_args(args=argList)
    args= vars(ar)
    
    genes= parseGenes(args['geneset'])
    d= unpickle(args['pickledCDSFile'])
    
    if args['keep']==True:
        AddTab(args['tabFile'], args['outprefix'], genes)
        AddCDS(d, args['outprefix'], genes)
    
    elif args['remove']==True:
        RemoveTab(args['tabFile'], args['outprefix'], genes)
        RemoveCDS(d, args['outprefix'], genes)
    
main(sys.argv[1:])