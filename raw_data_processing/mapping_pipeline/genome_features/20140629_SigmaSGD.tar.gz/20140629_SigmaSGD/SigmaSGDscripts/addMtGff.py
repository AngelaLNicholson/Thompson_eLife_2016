#140626 MKT
# also add the corresponding chrmt annotations to the .gff file

import sys


def writeCombinedGff(sigmagff, s288cgff, newgff):
    
    #get all the annotations corresponding to the chrmt:
    mtlines=[]
    k= open(s288cgff, 'r')
    for line in k:
        if line.startswith('chrmt'):
            mtlines.append(line)
    k.close()
    
    #modify the new gff
    f= open(sigmagff, 'r')
    g= open(newgff, 'w')
    for line in f:
        if line.startswith('###'):
            break
        else:
            g.write(line)
     
    for line in mtlines:
        g.write(line)
    
    f.close()
    g.close()
    
def main():
    sigmagff, s288cgff, newgff= sys.argv[1:]
    
    #update the gff file
    writeCombinedGff(sigmagff, s288cgff, newgff)

main()