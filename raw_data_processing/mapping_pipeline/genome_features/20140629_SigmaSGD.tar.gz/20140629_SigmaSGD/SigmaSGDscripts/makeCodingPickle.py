#140626 MKT
#to make the sigma_codingCDS.p file

import sys
import cPickle as pickle
import operator

Cs={'A':'T', 'T':'A', 'C':'G', 'G':'C', 'N':'N'}
stop_codons= set(['TAA', 'TAG', 'TGA'])

def unpickle(pfile):
    f= open(pfile, 'r')
    d= pickle.load(f)
    f.close()
    return d

def rc(seq):
    '''return the r.c. of the sequence'''
    
    c=''
    for i in seq:
        c+= Cs[i]
    
    rc= c[::-1]
    return rc

def getSeq(anns, gene, genome):

#find the sequence corresponding to these annotations:
    seq=''
    chrom= anns[gene]['chr']
    strand= anns[gene]['strand']

    for i in range(0, len(anns[gene]['exon_starts'])):
        seq+= genome[chrom][anns[gene]['exon_starts'][i]-1:anns[gene]['exon_ends'][i]]

    juncs= anns[gene]['exon_starts']
    if len(juncs)>1:
        t= 'spliced'
    else:
        t='unspliced'
        
    if strand=='-':
        seq= rc(seq)

    return seq

def parseGff(annfile):
    '''Parse the gff provided by Matt Edwards. I think that gff should also be 1-based and inclusive'''
    annd={}
    f= open(annfile, 'r')
    for line in f:
        if line.startswith('#'):
            continue
        elif line.startswith('###'):
            break
        fields= line.strip('\n').split('\t')
        chrom= fields[0]
        region= fields[2]
        start= int(fields[3])
        end= int(fields[4])
        strand= fields[6]
        subattributes= fields[8].split(';')
        keys= [i.split('=')[0] for i in subattributes]
        vals=[]
        for i in subattributes:
            try:
                vals.append(i.split('=')[1])
            except:
                vals.append('')
        attd= dict(zip(keys, vals))
        #print attd
	if region=='CDS':
            ID= attd['Parent'].split('_')[0] #get rid of the _mRNA part
            if ID not in annd: #could be there already if it's a second exon
                annd[ID]={}
                annd[ID]['chr']= chrom
                annd[ID]['strand']= strand
                   
                annd[ID]['exons']= [[start, end]]
                
            else:
                annd[ID]['exons'].append([start, end])
    
    #sort the exons by boundary, assume that there can only be one leftmost exon and one rightmost. the rightmost will also be the end of the gene
    for gene in annd:
        exonbounds= annd[gene]['exons']
        exonbounds.sort(key=operator.itemgetter(0))
        
        annd[gene]['start']= exonbounds[0][0]
        annd[gene]['end']= exonbounds[-1][1]
        
        exon_starts=[]
        exon_ends=[]
        
        for i in annd[gene]['exons']:
            exon_starts.append(i[0])
            exon_ends.append(i[1])
            
        annd[gene]['exon_starts']= exon_starts
        annd[gene]['exon_ends']= exon_ends
        	
    return annd

def writeOut(annd, genomed, outfile):

    correctATG=0
    incorrectATG=0
    correctStop=0
    incorrectStop=0
    div3=0
    
    d= {}    
    for gene in annd:
        d[gene]={}
        seq= getSeq(annd, gene, genomed)
        if seq.startswith('ATG'):
            correctATG+=1
        else:
            incorrectATG+=1
        
        if seq[-3:] in stop_codons:
            correctStop+=1
        else:
            incorrectStop+=1
            
        length= len(seq)
	if length%3==0:
	    div3+=1
        d[gene]['length']= length
        d[gene]['seq']=seq
    
    f= open(outfile, 'w')
    pickle.dump(d, f)
    f.close()
    print 'correctATG', correctATG
    print 'incorrectATG', incorrectATG
    print 'correctStop', correctStop
    print 'incorrectStop', incorrectStop
    print 'div3', div3
    
def main():
    
    annfile, genomefile, outfile= sys.argv[1:]
    
    annd= parseGff(annfile)
    genomed= unpickle(genomefile)
    
    writeOut(annd, genomed, outfile)
main()