#140626 MKT
# need to remove all the stuff after the last | from the sigma contig names, add the mt fasta as well

import sys

def writeOut(sigmafasta, mtfasta, newfasta):
    f= open(sigmafasta, 'r')
    g= open(mtfasta, 'r')
    k= open(newfasta, 'w')

    for line in f:
        if line.startswith('>'):
            line= '|'.join(line.strip('\n').split('|')[0:-1])+'|'+'\n'
        k.write(line)
    
    for line in g:
        if line.startswith('>'):
            line='>chrmt\n'
        k.write(line)
    
    f.close()
    g.close()
    k.close()
    
def main():
    sigmafasta, mtfasta, newfasta= sys.argv[1:]
    
    #update the gff file
    writeOut(sigmafasta, mtfasta, newfasta)

main()