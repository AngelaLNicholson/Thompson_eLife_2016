#140624 MKT
#extract splice junctions from the sigma .tab file, suitable for use with tophat

import sys

def main():
    infile, outfile= sys.argv[1:]
    f= open(infile, 'r')
    g= open(outfile, 'w')
    for line in f:
        fields= line.strip('\n').split('\t')
        chrom= fields[1]
        strand= fields[2]
        exon_starts= fields[6].split(',')
        exon_stops= fields[7].split(',')
        
        for i in range(0, len(exon_starts)-1): #there are n-1 junctions
            exon_end= int(exon_stops[i])-1 #subtract 1 to make zero based
            next_exon_start= int(exon_starts[i+1])-1
            
            newlinevals=[chrom, exon_end, next_exon_start, strand]
            newlinestrings=[str(i) for i in newlinevals]
            g.write('\t'.join(newlinestrings)+'\n')
    
    f.close()
    g.close()

main()