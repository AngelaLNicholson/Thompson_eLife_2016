#140625 MKT
# To make the sigma .tab from the SGD .gff to be used by the pipeline

import sys
import operator

def parseGff(annfile):
    '''Parse the gff provided by Matt Edwards. I think that gff should also be 1-based and inclusive'''
    annd={}
    f= open(annfile, 'r')
    for line in f:
        if line.startswith('#'):
            continue
        elif line.startswith('###'):
            break
        fields= line.strip('\n').split('\t')
        chrom= fields[0]
        region= fields[2]
        start= int(fields[3])
        end= int(fields[4])
        strand= fields[6]
        subattributes= fields[8].split(';')
        keys= [i.split('=')[0] for i in subattributes]
        vals=[]
        for i in subattributes:
            try:
                vals.append(i.split('=')[1])
            except:
                vals.append('')
        attd= dict(zip(keys, vals))
        #print attd
    
        if region=='CDS':
            ID= attd['Parent'].split('_')[0] #get rid of the _mRNA part
            if ID not in annd: #could be there already if it's a second exon
                annd[ID]={}
                annd[ID]['chr']= chrom
                annd[ID]['strand']= strand
                   
                annd[ID]['exons']= [[start, end]]
                
            else:
                annd[ID]['exons'].append([start, end])
    
    #sort the exons by boundary, assume that there can only be one leftmost exon and one rightmost. the rightmost will also be the end of the gene
    for gene in annd:
        exonbounds= annd[gene]['exons']
        exonbounds.sort(key=operator.itemgetter(0))
        
        annd[gene]['start']= exonbounds[0][0]
        annd[gene]['end']= exonbounds[-1][1]
        
        exon_starts=[]
        exon_ends=[]
        
        for i in annd[gene]['exons']:
            exon_starts.append(i[0])
            exon_ends.append(i[1])
            
        annd[gene]['exon_starts']= exon_starts
        annd[gene]['exon_ends']= exon_ends
        
			
    return annd


def writeOut(annd, outfile):
    
    g= open(outfile, 'w')
    
    for gene in annd:
        startstrings=[str(i) for i in annd[gene]['exon_starts']]
        exonstarts= ','.join(startstrings)
        endstrings=[str(i) for i in annd[gene]['exon_ends']]
        exonends= ','.join(endstrings)
        
        line=[gene, annd[gene]['chr'], annd[gene]['strand'], str(annd[gene]['start']), str(annd[gene]['end']), str(len(annd[gene]['exon_starts'])), exonstarts, exonends]
        linetowrite='\t'.join(line)+'\n'
        g.write(linetowrite)
    g.close()
        

def main():
    infile, outfile= sys.argv[1:]
    annd=parseGff(infile)
    
    writeOut(annd, outfile)
    
main()