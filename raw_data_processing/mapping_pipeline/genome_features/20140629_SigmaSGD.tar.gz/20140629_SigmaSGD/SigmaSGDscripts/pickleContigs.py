#140625 MKT
#pickle the contigs for the sigma1278b genome form SGD

import sys, pickle

genome, saved_genome= sys.argv[1:]

def get_chr_seq(genome): #given multi-fasta file, build dictionary of the form {'+':{'chr1':'atgcg...', 'chr2':'gctg...,...}, '-':{'chr1':'tacgc...', ..}}
	g= open(genome, 'r')
	
	genome_dict= {}
	for line in g:
		line=line.strip('\n')
		if line.startswith('>'):
			contigname= line[1:]
			genome_dict[contigname]=''
		else:
			genome_dict[contigname]+= line
	
	g.close()
	return genome_dict	

def main():
	genome_dict= get_chr_seq(genome)
	s= open(saved_genome, 'w') #open a file to write the pickled dictionary
	pickle.dump(genome_dict, s)
	s.close()

	#print genome_dict

main()


